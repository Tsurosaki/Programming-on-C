#ifndef MATRIX_H
#define MATRIX_H

void compute_matrices(double **matrix1, double **matrix2, double **result, int n, char operation);
#endif